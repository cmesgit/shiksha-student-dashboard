import {
  useRoomContext,
  useLocalParticipant,
} from "@livekit/components-react";
import { useEffect, useRef, useState } from "react";
import groupSessionService from "../../api/groupSessionService";

/**
 * GroupSessionControlBar.jsx
 *
 * Group-session-only control bar.
 * This file is intentionally separate from ControlBar.jsx so Private Sessions
 * and normal Live Sessions are not affected.
 */
export default function GroupSessionControlBar({
  onLeave,
  role,
  activePanel,
  onTogglePanel,
  session,
  isHost = false,
  onHostEndSession = null,
}) {
  const isStudent = role !== "PRESENTER";

  const room = useRoomContext();
  const { localParticipant } = useLocalParticipant();

  const [micOn, setMicOn] = useState(false);
  const [videoOn, setVideoOn] = useState(false);
  const [screenOn, setScreenOn] = useState(false);
  const [canUnmute, setCanUnmute] = useState(false);
  const [canVideo, setCanVideo] = useState(false);

  const [otherOpen, setOtherOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [isLocked, setIsLocked] = useState(
    (session?.admitMode || session?.admit_mode || "").toLowerCase() === "locked"
  );
  const [lockBusy, setLockBusy] = useState(false);

  const mountedAtRef = useRef(Date.now());
  const otherRef = useRef(null);

  const roomCode = session?.shortCode || session?.short_code || session?.id || "";
  const roomCodeText = roomCode ? String(roomCode) : "—";

  const getStartedMs = () => {
    const raw =
      session?.roomStartedAt ||
      session?.room_started_at ||
      session?.roomStarted ||
      null;

    const parsed = raw ? new Date(raw).getTime() : NaN;
    return Number.isNaN(parsed) ? mountedAtRef.current : parsed;
  };

  const formatTime = (s) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  };

  useEffect(() => {
    const onClick = (e) => {
      if (otherRef.current && !otherRef.current.contains(e.target)) {
        setOtherOpen(false);
      }
    };

    if (otherOpen) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [otherOpen]);

  // Timer uses backend room_started_at, so rejoin does not reset to zero.
  useEffect(() => {
    const update = () => {
      const startedMs = getStartedMs();
      setElapsed(Math.max(0, Math.floor((Date.now() - startedMs) / 1000)));
    };

    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, [session?.roomStartedAt, session?.room_started_at, session?.id]);

  useEffect(() => {
    if (!isStudent || !localParticipant) return;

    localParticipant.setMicrophoneEnabled(false);
    localParticipant.setCameraEnabled(false);
    setMicOn(false);
    setVideoOn(false);
  }, [isStudent, localParticipant]);

  useEffect(() => {
    if (isStudent || !localParticipant) return;

    setMicOn(!!localParticipant.isMicrophoneEnabled);
    setVideoOn(!!localParticipant.isCameraEnabled);
    setScreenOn(!!localParticipant.isScreenShareEnabled);
  }, [isStudent, localParticipant]);

  useEffect(() => {
    if (!room || !localParticipant) return;

    const handleData = (payload) => {
      try {
        const text = new TextDecoder().decode(payload);
        const msg = JSON.parse(text);

        if (msg.type === "force-mute") {
          localParticipant.setMicrophoneEnabled(false);
          setMicOn(false);
          setCanUnmute(false);
        }

        if (msg.type === "force-unmute" || msg.type === "allow-mic") {
          setCanUnmute(true);
          if (msg.type === "force-unmute") {
            localParticipant.setMicrophoneEnabled(true);
            setMicOn(true);
          }
        }

        if (msg.type === "revoke-mic") {
          setCanUnmute(false);
          localParticipant.setMicrophoneEnabled(false);
          setMicOn(false);
        }

        if (msg.type === "force-camera-off") {
          localParticipant.setCameraEnabled(false);
          setVideoOn(false);
          setCanVideo(false);
        }

        if (msg.type === "force-camera-on" || msg.type === "allow-camera") {
          setCanVideo(true);
          if (msg.type === "force-camera-on") {
            localParticipant.setCameraEnabled(true);
            setVideoOn(true);
          }
        }

        if (msg.type === "revoke-camera") {
          setCanVideo(false);
          localParticipant.setCameraEnabled(false);
          setVideoOn(false);
        }
      } catch {}
    };

    room.on("dataReceived", handleData);
    return () => room.off("dataReceived", handleData);
  }, [room, localParticipant]);

  const toggleMic = async () => {
    if (!localParticipant) return;
    if (isStudent && !canUnmute && !micOn) return;

    const next = !micOn;
    await localParticipant.setMicrophoneEnabled(next);
    setMicOn(next);
  };

  const toggleVideo = async () => {
    if (!localParticipant) return;
    if (isStudent && !canVideo && !videoOn) return;

    const next = !videoOn;
    await localParticipant.setCameraEnabled(next);
    setVideoOn(next);
  };

  const toggleScreen = async () => {
    if (!localParticipant) return;

    const next = !screenOn;
    try {
      await localParticipant.setScreenShareEnabled(next);
      setScreenOn(next);
    } catch (e) {
      console.error("screen share failed", e);
    }
  };

  const leaveRoom = async () => {
    await room.disconnect();
    if (onLeave) onLeave();
  };

  const copySessionId = async () => {
    try {
      await navigator.clipboard.writeText(roomCodeText);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      window.prompt("Copy this session ID:", roomCodeText);
    }
  };

  const muteAllParticipants = async () => {
    if (!isHost || !localParticipant) return;

    try {
      const payload = new TextEncoder().encode(JSON.stringify({ type: "force-mute" }));
      await localParticipant.publishData(payload, { reliable: true });
      setOtherOpen(false);
    } catch (e) {
      console.error("Mute all participants failed", e);
    }
  };

  const toggleLockSession = async () => {
    if (!isHost || !session?.id || lockBusy) return;

    const nextMode = isLocked ? "open" : "locked";
    setLockBusy(true);

    try {
      await groupSessionService.setAdmitMode(session.id, nextMode);
      setIsLocked(nextMode === "locked");
      setOtherOpen(false);
    } catch (e) {
      console.error("Lock session failed", e);
    } finally {
      setLockBusy(false);
    }
  };

  const openSettings = () => {
    setOtherOpen(false);
  };

  const endSession = () => {
    setOtherOpen(false);
    if (onHostEndSession) onHostEndSession();
  };

  return (
    <div className="gs-control-bar">
      <div className="gs-cb-timer">{formatTime(elapsed)}</div>

      <div className="gs-cb-center">
        <button className="gs-cb-btn" onClick={toggleMic} title={micOn ? "Mute" : "Unmute"}>
          <div className={`gs-cb-icon ${micOn ? "" : "gs-cb-icon--off"}`}>
            {micOn ? (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
            ) : (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
            )}
          </div>
          <span className="gs-cb-label">{micOn ? "Mute" : "Unmute"}</span>
        </button>

        <button className="gs-cb-btn" onClick={toggleVideo} title={videoOn ? "Turn off camera" : "Turn on camera"}>
          <div className={`gs-cb-icon ${videoOn ? "" : "gs-cb-icon--off"}`}>
            {videoOn ? (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
            ) : (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34l1 1L23 7v10"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
            )}
          </div>
          <span className="gs-cb-label">Video</span>
        </button>

        <button className="gs-cb-btn" onClick={toggleScreen} title="Share screen">
          <div className={`gs-cb-icon ${screenOn ? "gs-cb-icon--active" : ""}`}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><polyline points="8 21 12 17 16 21"/><line x1="12" y1="17" x2="12" y2="11"/><polyline points="9 14 12 11 15 14"/></svg>
          </div>
          <span className="gs-cb-label">Screen</span>
        </button>

        <div className="gs-cb-other-wrap" ref={otherRef}>
          <button className={`gs-cb-btn ${otherOpen ? "gs-cb-btn--active" : ""}`} title="More options" onClick={() => setOtherOpen((v) => !v)}>
            <div className="gs-cb-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>
            </div>
            <span className="gs-cb-label">Other</span>
          </button>

          {otherOpen && (
            <div className="gs-cb-other-menu">
              <div className="gs-cb-other-session">
                <span className="gs-cb-other-label">Session ID</span>
                <div className="gs-cb-other-code-row">
                  <strong>{roomCodeText}</strong>
                  <button type="button" onClick={copySessionId} title="Copy session ID">
                    {copied ? "✓" : <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>}
                  </button>
                </div>
              </div>

              {isHost && (
                <>
                  <button type="button" className="gs-cb-other-item" onClick={muteAllParticipants}><span>Mute All Participants</span><span className="gs-cb-other-check" /></button>
                  <button type="button" className="gs-cb-other-item" disabled={lockBusy} onClick={toggleLockSession}><span>{isLocked ? "Unlock Session" : "Lock Session"}</span><span className={`gs-cb-other-check ${isLocked ? "gs-cb-other-check--on" : ""}`} /></button>
                </>
              )}

              <button type="button" className="gs-cb-other-item" onClick={openSettings}><span>Voice &amp; Video Settings</span><span>⚙</span></button>

              {isHost && <button type="button" className="gs-cb-other-item gs-cb-other-item--danger" onClick={endSession}><span>End Session</span><span>⏻</span></button>}
            </div>
          )}
        </div>

        <button className="gs-cb-btn" onClick={leaveRoom} title="Leave session">
          <div className="gs-cb-icon gs-cb-icon--leave">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" transform="rotate(135 12 12)"/></svg>
          </div>
          <span className="gs-cb-label">Leave</span>
        </button>
      </div>

      <div className="gs-cb-right">
        <button className={`gs-cb-side-btn ${activePanel === "info" ? "gs-cb-side-btn--active" : ""}`} onClick={() => onTogglePanel("info")} title="Session info">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
          <span>Info</span>
        </button>

        <button className={`gs-cb-side-btn ${activePanel === "people" ? "gs-cb-side-btn--active" : ""}`} onClick={() => onTogglePanel("people")} title="Participants">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          <span>People</span>
        </button>

        <button className={`gs-cb-side-btn ${activePanel === "chat" ? "gs-cb-side-btn--active" : ""}`} onClick={() => onTogglePanel("chat")} title="Chat">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          <span>Chat</span>
        </button>
      </div>
    </div>
  );
}
